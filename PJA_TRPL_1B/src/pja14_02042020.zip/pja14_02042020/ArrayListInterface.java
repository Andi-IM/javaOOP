/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pja14_02042020;

/**
 *
 * @author Andi
 */
public interface ArrayListInterface {
    public int menu(int pilihan); // EXPERIMENTAL //
    public void display();
    public void find();
    public void delete();
    public void update();
}
